import restaurant.*;

import java.util.Scanner;

public class Restaurant {
    public static void main(String[] args){
        while (true) {
            System.out.println("1. list items  2.order 3.recipt");
            Scanner obj = new Scanner(System.in);

            int choice  = obj.nextInt();

            switch(choice){
                case 1 :
                    List.list_item();
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    break;
            }

        }
    }


}
