package restaurant;

public class Check {

    public void Check_type(Item pizza){
        if (pizza.get_type().equals("med")){
            pizza.price = 5;
        }
        else{
            pizza.price = 10;
        }


    }
}
