package restaurant;

public class Item {
    String name;
    String type;
    int price;

    public Item(String name, String type){
        this.name = name;
        this.type = type;


    }

    public int get_price(){
        return price;

    }

    public String get_type(){
        return type;

    }

    public String get_name(){
        return name;

    }

    public void print_item(){
        System.out.println(name+ " "+type+" : "+price);
    }

}
