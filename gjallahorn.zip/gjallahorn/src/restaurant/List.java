package restaurant;

public class List {

    static int menu_size = 3;
    static Item[] menu;




    public static void list_item(){
        for (int x = 0;x<menu_size;x++){
            menu[x].print_item();

        }
    }


}
