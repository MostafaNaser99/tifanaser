package restaurant;

public class Order {
    Item[] order;
    int order_size = 0;

    public void add_order(Item pizza){
        order[order_size] = pizza;
        order_size++;
    }
}
