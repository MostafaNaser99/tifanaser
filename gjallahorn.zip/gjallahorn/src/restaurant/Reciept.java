package restaurant;

public class Reciept {
    int total = 0;

    public void print_recipt(Item[] order, int order_size){
        for(int x = 0;x<order_size;x++){
            order[x].print_item();
            total =+order[x].get_price();
        }
        System.out.println("total: "+total);
    }

}
