package com.example.summer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Distance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance);

        Button d_back=(Button) findViewById(R.id.d_menu);
        final ListView distnaceList=(ListView) findViewById(R.id.distancelist);
        final ArrayAdapter<String> listadapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        distnaceList.setAdapter(listadapter);
        listadapter.add("meter to mile");
        listadapter.add("mile to meter");
        listadapter.add("meter to foot");
        listadapter.add("foot to meter");
        listadapter.add("meter to inch");
        listadapter.add("inch to meter");
        listadapter.add("meter to kilometer");
        listadapter.add("kilometer to meter");

        distnaceList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(TextUtils.isEmpty(((EditText)findViewById(R.id.before)).getText().toString())==true)
                {
                    Toast.makeText(getApplicationContext(),"Please Enter a number!",Toast.LENGTH_LONG).show();
                }
                else
                {
                    String choice=distnaceList.getItemAtPosition(i).toString();
                    double input=Double.parseDouble(((EditText)findViewById(R.id.before)).getText().toString());
                    distanceConversions conv=new distanceConversions();

                    TextView answer=(TextView) findViewById(R.id.after);
                    conv.setValue(input);
                    switch(choice)
                    {
                        case"meter to mile":
                            answer.setText(String.valueOf(conv.m_mile()));
                            answer.append(" mi");
                            break;
                        case"mile to meter":
                            answer.setText(String.valueOf(conv.mile_m()));
                            answer.append(" m");
                            break;
                        case"meter to foot":
                            answer.setText(String.valueOf(conv.m_foot()));
                            answer.append(" ft");
                            break;
                        case"foot to meter":
                            answer.setText(String.valueOf(conv.foot_m()));
                            answer.append(" m");
                            break;
                        case"meter to inch":
                            answer.setText(String.valueOf(conv.m_inch()));
                            answer.append(" in");
                            break;
                        case"inch to meter":
                            answer.setText(String.valueOf(conv.inch_m()));
                            answer.append(" m");
                            break;
                        case"meter to kilometer":
                            answer.setText(String.valueOf(conv.m_km()));
                            answer.append(" km");
                            break;
                        case"kilometer to meter":
                            answer.setText(String.valueOf(conv.km_m()));
                            answer.append(" m");
                            break;

                    }
                }



            }
        });


        d_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Distance.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}