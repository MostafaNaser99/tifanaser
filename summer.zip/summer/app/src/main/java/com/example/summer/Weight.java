package com.example.summer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.summer.R;

public class Weight extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        Button w_back=(Button) findViewById(R.id.w_menu);
        Button calculate=(Button) findViewById(R.id.calculate);
        final Spinner options=(Spinner)findViewById(R.id.w_conversions);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(((EditText)findViewById(R.id.w_before)).getText().toString())==true)
                {
                    Toast.makeText(getApplicationContext(),"Please Enter a number!",Toast.LENGTH_LONG).show();
                }
                else {
                    TextView Res = (TextView) findViewById(R.id.w_after);
                    String choice = options.getSelectedItem().toString();
                    double input = Double.parseDouble(((EditText) findViewById(R.id.w_before)).getText().toString());
                    weightConversions conv = new weightConversions();
                    conv.setValue(input);
                    switch (choice) {
                        case "gram to kilogram":
                            Res.setText(String.valueOf(conv.g_kg()));
                            Res.append(" kg");
                            break;
                        case "kilogram to gram":
                            Res.setText(String.valueOf(conv.kg_g()));
                            Res.append(" g");
                            break;
                        case "pound to kilogram":
                            Res.setText(String.valueOf(conv.lb_kg()));
                            Res.append(" kg");
                            break;
                        case "kilogram to pound":
                            Res.setText(String.valueOf(conv.kg_lb()));
                            Res.append(" lbs");
                            break;
                        case "tonne to kilogram":
                            Res.setText(String.valueOf(conv.t_kg()));
                            Res.append(" kg");
                            break;
                        case "kilogram to tonne":
                            Res.setText(String.valueOf(conv.kg_t()));
                            Res.append(" t");
                            break;
                        case "ounce to kilogram":
                            Res.setText(String.valueOf(conv.oz_kg()));
                            Res.append(" kg");
                            break;
                        case "kilogram to ounce":
                            Res.setText(String.valueOf(conv.kg_oz()));
                            Res.append(" oz");
                            break;
                    }
                }

            }
        });

        w_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Weight.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}