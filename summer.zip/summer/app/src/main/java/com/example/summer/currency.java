package com.example.summer;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class currency extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency);

        Button d_back=(Button) findViewById(R.id.d_menu);
        final ListView distnaceList=(ListView) findViewById(R.id.distancelist);
        final ArrayAdapter<String> listadapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        distnaceList.setAdapter(listadapter);
        listadapter.add("usd to egp");
        listadapter.add("egp to usd");


        distnaceList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if(TextUtils.isEmpty(((EditText)findViewById(R.id.before)).getText().toString())==true)
                {
                    Toast.makeText(getApplicationContext(),"Please Enter a number!",Toast.LENGTH_LONG).show();
                }
                else
                {
                    String choice=distnaceList.getItemAtPosition(i).toString();
                    double input=Double.parseDouble(((EditText)findViewById(R.id.before)).getText().toString());
                    currencyConverter conv=new currencyConverter();

                    TextView answer=(TextView) findViewById(R.id.after);
                    conv.setValue(input);
                    switch(choice)
                    {
                        case"usd to egp":
                            answer.setText(String.valueOf(conv.usd_egp()));
                            answer.append(" egp");
                            break;
                        case"egp to usd":
                            answer.setText(String.valueOf(conv.egp_usd()));
                            answer.append(" usd");
                            break;


                    }
                }



            }
        });


        d_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(currency.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}
