package com.example.summer;

import androidx.appcompat.app.AppCompatActivity;

public class currencyConverter  extends AppCompatActivity {
    public double value=0;

    public void setValue(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public double usd_egp()
    {
        return value*20;
    }
    public double egp_usd()
    {
        return value*.05;
    }

}
