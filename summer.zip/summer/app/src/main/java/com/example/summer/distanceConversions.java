package com.example.summer;

import androidx.appcompat.app.AppCompatActivity;

public class distanceConversions extends AppCompatActivity {
    public double value=0;

    public void setValue(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public double m_mile()
    {
        return value*0.000621371;
    }
    public double mile_m()
    {
        return value*1609.34;
    }
    public double m_foot()
    {
        return value*3.28084;
    }
    public double foot_m()
    {
        return value*0.3048;
    }
    public double m_inch()
    {
        return value*39.3701;
    }
    public double inch_m()
    {
        return value*0.0254;
    }
    public double m_km()
    {
        return value*0.001;
    }
    public double km_m()
    {
        return value*1000;
    }
}
