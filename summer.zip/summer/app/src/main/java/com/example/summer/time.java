package com.example.summer;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class time extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);

        Button d_back=(Button) findViewById(R.id.d_menu);
        d_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(time.this,MainActivity.class);
                startActivity(i);
            }
        });





                if(TextUtils.isEmpty(((EditText)findViewById(R.id.before)).getText().toString())==true)
                {
                    Toast.makeText(getApplicationContext(),"Please Enter a number!",Toast.LENGTH_LONG).show();
                }
                else
                {
                    double input=Double.parseDouble(((EditText)findViewById(R.id.before)).getText().toString());
                    timeConverter conv=new timeConverter();

                    TextView answer=(TextView) findViewById(R.id.after);
                    conv.setValue(input);


                }
                }





        }







