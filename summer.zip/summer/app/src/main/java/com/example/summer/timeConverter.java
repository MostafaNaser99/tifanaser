package com.example.summer;

import androidx.appcompat.app.AppCompatActivity;

public class timeConverter extends AppCompatActivity {
    public double value=0;

    public void setValue(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public double hr_min()
    {
        return value*60;
    }
    public double min_hr()
    {
        return value/60;
    }

}
