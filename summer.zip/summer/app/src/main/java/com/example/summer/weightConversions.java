package com.example.summer;

public class weightConversions extends MainActivity {
    public double value=0;

    public void setValue(double value) {
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    public double g_kg()
    {
        return value*0.001;
    }
    public double kg_g()
    {
        return value*1000;
    }
    public double lb_kg()
    {
        return value*0.453592;
    }
    public double kg_lb()
    {
        return value*2.20462;
    }
    public double t_kg()
    {

        return value*1000;
    }
    public double kg_t()

    {
        return value*0.001;
    }
    public double oz_kg()

    {
        return value*0.0283495;
    }
    public double kg_oz()
    {
        return value*35.274;
    }

}
